muban.首图2.二级.tabs = '.dropdown-menu li';
muban.首图2.二级.重定向='js:let url = jsp.pd(html,"a.btn-primary&&href");log(url);html = request(url)';
var rule = Object.assign(muban.首图2,{
    title:'玄天',
    host:'https://m.7caa.com',
    url:'/list/fyclass-fypage.html',
    searchUrl:'/search/**----------fypage---.html',
    // lazy:'通用免嗅'
});